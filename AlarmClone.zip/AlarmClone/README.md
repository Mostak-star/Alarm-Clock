# Wake Mission (Alarmy-style alarm)
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync. Accept the prompt to create the Gradle wrapper.
2. Run on a real phone. Allow notifications and camera when asked.
3. Photo mission uses ML Kit labels: use common objects (toothbrush, cup, bottle, laptop). Check the "I see:" line to see what the model detects.
Kits: Compose, Room (KSP), CameraX, ML Kit barcode scanning, ML Kit image labeling.

## Get the APK without Android Studio
Upload this folder's contents to a new GitHub repo. The Actions tab builds the APK automatically; download "WakeMission-APK" from the finished run.
