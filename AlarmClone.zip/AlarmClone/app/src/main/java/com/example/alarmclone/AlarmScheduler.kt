package com.example.alarmclone

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {

    fun nextTrigger(a: AlarmEntity): Long {
        val now = System.currentTimeMillis()
        val base = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        for (i in 0..7) {
            val c = (base.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, i) }
            val idx = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Mon=0 ... Sun=6
            val dayOk = a.days == 0 || (a.days and (1 shl idx)) != 0
            if (dayOk && c.timeInMillis > now) return c.timeInMillis
        }
        return base.timeInMillis + 24L * 3600 * 1000
    }

    private fun pending(ctx: Context, id: Int) = PendingIntent.getBroadcast(
        ctx, id, Intent(ctx, AlarmReceiver::class.java).putExtra(EXTRA_ID, id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(ctx: Context, a: AlarmEntity) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(nextTrigger(a), show), pending(ctx, a.id))
    }

    fun cancel(ctx: Context, a: AlarmEntity) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, a.id))
    }
}
