package com.example.alarmclone

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import java.util.concurrent.Executors
import kotlin.math.sqrt
import kotlin.random.Random

@Composable
fun MissionHost(alarm: AlarmEntity, onSolved: () -> Unit) {
    when (runCatching { Mission.valueOf(alarm.mission) }.getOrDefault(Mission.NONE)) {
        Mission.NONE -> Button(onClick = onSolved) { Text("Dismiss") }
        Mission.MATH -> MathMission(onSolved)
        Mission.TYPING -> TypingMission(alarm.missionParam.ifBlank { "I am awake and ready for today" }, onSolved)
        Mission.SHAKE -> ShakeMission(30, onSolved)
        Mission.QR -> QrMission(alarm.missionParam, onSolved)
        Mission.PHOTO -> PhotoMission(alarm.missionParam.ifBlank { "toothbrush" }, onSolved)
    }
}

@Composable
fun MathMission(onSolved: () -> Unit) {
    val problems = remember {
        List(3) { Triple(Random.nextInt(12, 40), Random.nextInt(3, 10), Random.nextInt(10, 90)) }
    }
    var step by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    val (a, b, c) = problems[step]
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Solve ${step + 1} of 3", style = MaterialTheme.typography.titleMedium)
        Text("$a × $b + $c = ?", style = MaterialTheme.typography.displaySmall)
        OutlinedTextField(
            value = text, onValueChange = { text = it.filter(Char::isDigit); wrong = false },
            isError = wrong, singleLine = true, label = { Text("Answer") }
        )
        Button(onClick = {
            if (text.toIntOrNull() == a * b + c) {
                text = ""
                if (step == 2) onSolved() else step++
            } else wrong = true
        }) { Text("Check") }
    }
}

@Composable
fun TypingMission(phrase: String, onSolved: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Type this exactly", style = MaterialTheme.typography.titleMedium)
        Text(phrase, style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(value = text, onValueChange = {
            text = it
            if (it == phrase) onSolved()
        }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun ShakeMission(target: Int, onSolved: () -> Unit) {
    val ctx = LocalContext.current
    var count by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        var last = 0L
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
                val now = System.currentTimeMillis()
                if (g > 20f && now - last > 250) {
                    last = now; count++
                    if (count >= target) onSolved()
                }
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(l) }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Shake your phone!", style = MaterialTheme.typography.headlineSmall)
        Text("$count / $target", style = MaterialTheme.typography.displayMedium)
        LinearProgressIndicator(progress = { count / target.toFloat() }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun CameraGate(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    if (granted) content() else Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Camera permission is needed for this mission")
        Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
    }
}

@Composable
private fun CameraAnalysis(onFrame: (ImageProxy) -> Unit) {
    val ctx = LocalContext.current
    val owner = ctx as LifecycleOwner
    val executor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(Unit) { onDispose { executor.shutdown() } }
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(380.dp),
        factory = { c ->
            val view = PreviewView(c)
            val future = ProcessCameraProvider.getInstance(c)
            future.addListener({
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                    .also { it.setAnalyzer(executor) { img -> onFrame(img) } }
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            }, ContextCompat.getMainExecutor(c))
            view
        }
    )
}

@Composable
fun QrMission(expected: String, onSolved: () -> Unit) {
    val scanner = remember { BarcodeScanning.getClient() }
    var done by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { scanner.close() } }
    CameraGate {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                if (expected.isBlank()) "Scan any QR code or barcode" else "Scan your registered QR code",
                style = MaterialTheme.typography.titleMedium
            )
            CameraAnalysis { proxy ->
                val media = proxy.image
                if (media == null || done) { proxy.close(); return@CameraAnalysis }
                val img = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                scanner.process(img)
                    .addOnSuccessListener { codes ->
                        val ok = codes.any { expected.isBlank() || it.rawValue == expected }
                        if (ok && !done) { done = true; onSolved() }
                    }
                    .addOnCompleteListener { proxy.close() }
            }
        }
    }
}

@Composable
fun PhotoMission(target: String, onSolved: () -> Unit) {
    val labeler = remember { ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS) }
    var done by remember { mutableStateOf(false) }
    var seen by remember { mutableStateOf("") }
    DisposableEffect(Unit) { onDispose { labeler.close() } }
    CameraGate {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Point the camera at: $target", style = MaterialTheme.typography.titleMedium)
            CameraAnalysis { proxy ->
                val media = proxy.image
                if (media == null || done) { proxy.close(); return@CameraAnalysis }
                val img = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                labeler.process(img)
                    .addOnSuccessListener { labels ->
                        seen = labels.take(3).joinToString { it.text }
                        val ok = labels.any { it.confidence > 0.6f && it.text.contains(target, ignoreCase = true) }
                        if (ok && !done) { done = true; onSolved() }
                    }
                    .addOnCompleteListener { proxy.close() }
            }
            Text("I see: $seen", style = MaterialTheme.typography.bodySmall)
        }
    }
}
