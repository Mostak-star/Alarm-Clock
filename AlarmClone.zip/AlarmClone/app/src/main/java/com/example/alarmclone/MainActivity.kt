package com.example.alarmclone

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

class AlarmViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).alarmDao()
    val alarms = dao.observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun save(a: AlarmEntity) = viewModelScope.launch {
        val id = dao.insert(a).toInt()
        AlarmScheduler.schedule(getApplication(), a.copy(id = id))
    }
    fun toggle(a: AlarmEntity, on: Boolean) = viewModelScope.launch {
        val n = a.copy(enabled = on)
        dao.update(n)
        if (on) AlarmScheduler.schedule(getApplication(), n) else AlarmScheduler.cancel(getApplication(), n)
    }
    fun delete(a: AlarmEntity) = viewModelScope.launch {
        AlarmScheduler.cancel(getApplication(), a)
        dao.delete(a)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { HomeScreen() } } }
    }
}

private val DAY_LETTERS = listOf("M", "T", "W", "T", "F", "S", "S")

private fun daysText(mask: Int): String = when (mask) {
    0 -> "Once"
    127 -> "Every day"
    else -> listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        .filterIndexed { i, _ -> mask and (1 shl i) != 0 }.joinToString(" ")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AlarmViewModel = viewModel()) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val alarms by vm.alarms.collectAsState()
    var adding by remember { mutableStateOf(false) }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) perms.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
    }
    val cameraPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    Scaffold(
        topBar = { TopAppBar(title = { Text("Wake Mission") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Default.Add, "Add alarm") }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(alarms, key = { it.id }) { a ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(String.format(Locale.getDefault(), "%02d:%02d", a.hour, a.minute), style = MaterialTheme.typography.displaySmall)
                            Text("${daysText(a.days)} · ${Mission.valueOf(a.mission).title}" +
                                (if (a.label.isNotBlank()) " · ${a.label}" else ""))
                        }
                        Switch(checked = a.enabled, onCheckedChange = { vm.toggle(a, it) })
                        IconButton(onClick = { vm.delete(a) }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }

    if (adding) {
        val tp = rememberTimePickerState(7, 0, false)
        var days by remember { mutableIntStateOf(0) }
        var mission by remember { mutableStateOf(Mission.MATH) }
        var param by remember { mutableStateOf("") }
        var label by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            confirmButton = {
                TextButton(onClick = {
                    if ((mission == Mission.QR || mission == Mission.PHOTO) &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                    ) cameraPerm.launch(Manifest.permission.CAMERA)
                    vm.save(AlarmEntity(hour = tp.hour, minute = tp.minute, days = days, label = label,
                        mission = mission.name, missionParam = param))
                    adding = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TimePicker(tp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        DAY_LETTERS.forEachIndexed { i, d ->
                            FilterChip(selected = days and (1 shl i) != 0,
                                onClick = { days = days xor (1 shl i) }, label = { Text(d) })
                        }
                    }
                    Text("Mission", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Mission.values().forEach { m ->
                            FilterChip(selected = mission == m, onClick = { mission = m }, label = { Text(m.title) })
                        }
                    }
                    when (mission) {
                        Mission.TYPING -> OutlinedTextField(param, { param = it }, label = { Text("Phrase to type") })
                        Mission.QR -> OutlinedTextField(param, { param = it }, label = { Text("Required QR text (blank = any code)") })
                        Mission.PHOTO -> OutlinedTextField(param, { param = it }, label = { Text("Object to photograph, e.g. toothbrush") })
                        else -> {}
                    }
                    OutlinedTextField(label, { label = it }, label = { Text("Label (optional)") }, singleLine = true)
                }
            }
        )
    }
}
