package com.example.alarmclone

import android.Manifest
import android.app.Activity
import android.app.Application
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

class AlarmViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).alarmDao()
    val alarms = dao.observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun save(a: AlarmEntity) = viewModelScope.launch {
        val toSave = a.copy(enabled = true)
        val id = dao.upsert(toSave).toInt()
        AlarmScheduler.schedule(getApplication(), toSave.copy(id = id))
    }
    fun toggle(a: AlarmEntity, on: Boolean) = viewModelScope.launch {
        val n = a.copy(enabled = on)
        dao.update(n)
        if (on) AlarmScheduler.schedule(getApplication(), n) else AlarmScheduler.cancel(getApplication(), n)
    }
    fun delete(a: AlarmEntity) = viewModelScope.launch {
        AlarmScheduler.cancel(getApplication(), a)
        dao.delete(a)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { HomeScreen() } } }
    }
}

private val DAY_LETTERS = listOf("M", "T", "W", "T", "F", "S", "S")

private fun daysText(mask: Int): String = when (mask) {
    0 -> "Once"
    127 -> "Every day"
    else -> listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        .filterIndexed { i, _ -> mask and (1 shl i) != 0 }.joinToString(" ")
}

private fun displayName(ctx: Context, uri: Uri): String = runCatching {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    }
}.getOrNull() ?: "Custom file"

private fun ringtoneTitle(ctx: Context, uri: String): String {
    if (uri.isBlank()) return "Default alarm sound"
    val u = Uri.parse(uri)
    return runCatching { RingtoneManager.getRingtone(ctx, u)?.getTitle(ctx) }.getOrNull()
        ?: displayName(ctx, u)
}

@Composable
fun HomeScreen(vm: AlarmViewModel = viewModel()) {
    val alarms by vm.alarms.collectAsState()
    var editing by remember { mutableStateOf<AlarmEntity?>(null) }
    val e = editing
    if (e != null) {
        EditorScreen(e, onSave = { vm.save(it); editing = null }, onCancel = { editing = null })
    } else {
        HomeContent(
            alarms = alarms,
            onAdd = { editing = AlarmEntity(hour = 7, minute = 0) },
            onEdit = { editing = it },
            onToggle = { a, on -> vm.toggle(a, on) },
            onDelete = { vm.delete(it) }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeContent(
    alarms: List<AlarmEntity>,
    onAdd: () -> Unit,
    onEdit: (AlarmEntity) -> Unit,
    onToggle: (AlarmEntity, Boolean) -> Unit,
    onDelete: (AlarmEntity) -> Unit
) {
    val ctx = LocalContext.current
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) perms.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Wake Mission") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, "Add alarm") }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            item { SetupCard() }
            items(alarms, key = { it.id }) { a ->
                Card(Modifier.fillMaxWidth().clickable { onEdit(a) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(String.format(Locale.getDefault(), "%02d:%02d", a.hour, a.minute), style = MaterialTheme.typography.displaySmall)
                            Text("${daysText(a.days)} · ${Mission.valueOf(a.mission).title}" +
                                (if (a.label.isNotBlank()) " · ${a.label}" else ""))
                            Text("Tap to edit", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = a.enabled, onCheckedChange = { onToggle(a, it) })
                        IconButton(onClick = { onDelete(a) }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }
}

/** Shows only the phone permissions that are still missing, each with a button that opens the right screen. */
@Composable
private fun SetupCard() {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val owner = remember { ctx.findLifecycleOwner() }
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, ev -> if (ev == Lifecycle.Event.ON_RESUME) refresh++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    val pkg = Uri.parse("package:${ctx.packageName}")
    val overlayOk = remember(refresh) { Settings.canDrawOverlays(ctx) }
    val batteryOk = remember(refresh) {
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    }
    val fsOk = remember(refresh) {
        Build.VERSION.SDK_INT < 34 || ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
    }
    if (overlayOk && batteryOk && fsOk) return

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Finish setup so alarms can show the mission screen", style = MaterialTheme.typography.titleSmall)
            if (!overlayOk) Button(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg))
            }) { Text("1. Allow display over other apps") }
            if (!fsOk && Build.VERSION.SDK_INT >= 34) Button(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg))
            }) { Text("2. Allow full-screen alarms") }
            if (!batteryOk) Button(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg))
            }) { Text("3. Stop battery optimization") }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
            }) { Text("Open app settings (autostart, lock screen)") }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(initial: AlarmEntity, onSave: (AlarmEntity) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onCancel() }

    var hour by remember { mutableIntStateOf(initial.hour) }
    var minute by remember { mutableIntStateOf(initial.minute) }
    var days by remember { mutableIntStateOf(initial.days) }
    var mission by remember { mutableStateOf(runCatching { Mission.valueOf(initial.mission) }.getOrDefault(Mission.MATH)) }
    var param by remember { mutableStateOf(initial.missionParam) }
    var label by remember { mutableStateOf(initial.label) }
    var ringtone by remember { mutableStateOf(initial.ringtone) }
    var volume by remember { mutableFloatStateOf(initial.volume / 100f) }
    var gradual by remember { mutableStateOf(initial.gradual) }
    var boost by remember { mutableStateOf(initial.boost) }
    var showTime by remember { mutableStateOf(false) }
    var showScan by remember { mutableStateOf(false) }
    var showTest by remember { mutableStateOf(false) }

    val cameraPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val ringPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            @Suppress("DEPRECATION")
            val u = r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            ringtone = u?.toString() ?: ""
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ringtone = u.toString()
        }
    }

    fun draft() = AlarmEntity(
        id = initial.id, hour = hour, minute = minute, days = days, label = label,
        mission = mission.name, missionParam = param, ringtone = ringtone,
        volume = (volume * 100).toInt().coerceIn(10, 100), gradual = gradual, boost = boost
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(if (initial.id == 0) "New alarm" else "Edit alarm", style = MaterialTheme.typography.headlineSmall)

        Section("Time and repeat") {
            OutlinedButton(onClick = { showTime = true }, modifier = Modifier.fillMaxWidth()) {
                Text(String.format(Locale.getDefault(), "%02d:%02d  (tap to change)", hour, minute))
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                DAY_LETTERS.forEachIndexed { i, d ->
                    FilterChip(selected = days and (1 shl i) != 0, onClick = { days = days xor (1 shl i) }, label = { Text(d) })
                }
            }
            Text(daysText(days), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(label, { label = it }, label = { Text("Label (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }

        Section("Mission to stop the alarm") {
            Mission.values().forEach { m ->
                Row(
                    Modifier.fillMaxWidth().clickable { mission = m }.padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = mission == m, onClick = { mission = m })
                    Column {
                        Text(m.title, style = MaterialTheme.typography.titleSmall)
                        Text(m.hint, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            when (mission) {
                Mission.TYPING -> OutlinedTextField(param, { param = it }, label = { Text("Phrase to type") }, modifier = Modifier.fillMaxWidth())
                Mission.PHOTO -> OutlinedTextField(param, { param = it }, label = { Text("Object, e.g. toothbrush, cup, bottle") }, modifier = Modifier.fillMaxWidth())
                Mission.QR -> {
                    Text(
                        if (param.isBlank()) "No code registered: any QR code or barcode will work"
                        else "Registered code: ${param.take(40)}"
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { showScan = true }) { Text("Scan to register") }
                        if (param.isNotBlank()) TextButton(onClick = { param = "" }) { Text("Clear") }
                    }
                }
                else -> {}
            }
            OutlinedButton(onClick = { showTest = true }, modifier = Modifier.fillMaxWidth()) { Text("Test this mission now") }
        }

        Section("Sound") {
            Text(ringtoneTitle(ctx, ringtone), style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                    if (ringtone.isNotBlank()) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(ringtone))
                    ringPicker.launch(i)
                }) { Text("Ringtones") }
                OutlinedButton(onClick = { filePicker.launch(arrayOf("audio/*")) }) { Text("My music file") }
            }
            if (ringtone.isNotBlank()) TextButton(onClick = { ringtone = "" }) { Text("Use default sound") }
            Text("Volume: ${(volume * 100).toInt().coerceIn(10, 100)}%")
            Slider(value = volume, onValueChange = { volume = it }, valueRange = 0.1f..1f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Gradually get louder")
                    Text("Fades in over 30 seconds", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = gradual, onCheckedChange = { gradual = it })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Volume boost")
                    Text("Louder than the phone's maximum. Keep the phone away from your ear.", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = boost, onCheckedChange = { boost = it })
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = {
                if ((mission == Mission.QR || mission == Mission.PHOTO) &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                ) cameraPerm.launch(Manifest.permission.CAMERA)
                onSave(draft())
            }) { Text("Save alarm") }
            OutlinedButton(onClick = onCancel) { Text("Cancel") }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showTime) {
        val st = rememberTimePickerState(hour, minute, false)
        AlertDialog(
            onDismissRequest = { showTime = false },
            confirmButton = { TextButton(onClick = { hour = st.hour; minute = st.minute; showTime = false }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text("Cancel") } },
            text = { TimePicker(st) }
        )
    }

    if (showScan) {
        Dialog(onDismissRequest = { showScan = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
                ) {
                    QrScanner("Scan the code you want to use") { code -> param = code; showScan = false }
                    TextButton(onClick = { showScan = false }) { Text("Cancel") }
                }
            }
        }
    }

    if (showTest) {
        Dialog(onDismissRequest = { showTest = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
                ) {
                    MissionHost(draft()) {
                        showTest = false
                        Toast.makeText(ctx, "Mission complete!", Toast.LENGTH_SHORT).show()
                    }
                    TextButton(onClick = { showTest = false }) { Text("Close preview") }
                }
            }
        }
    }
}
