package com.example.alarmclone

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(EXTRA_ID, -1)
        ContextCompat.startForegroundService(
            context, Intent(context, AlarmService::class.java).putExtra(EXTRA_ID, id)
        )
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.get(context).alarmDao().getAll()
                    .filter { it.enabled }
                    .forEach { AlarmScheduler.schedule(context, it) }
            } finally { pending.finish() }
        }
    }
}
