package com.example.alarmclone

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

class RingActivity : ComponentActivity() {
    companion object { @Volatile var visible = false }

    override fun onStart() { super.onStart(); visible = true }
    override fun onStop() { visible = false; super.onStop() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val id = intent.getIntExtra(EXTRA_ID, -1)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    RingScreen(id) {
                        stopService(Intent(this, AlarmService::class.java))
                        finish()
                    }
                }
            }
        }
    }
}

@Composable
fun RingScreen(id: Int, onSolved: () -> Unit) {
    val ctx = LocalContext.current
    var alarm by remember { mutableStateOf<AlarmEntity?>(null) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(id) {
        alarm = AppDatabase.get(ctx).alarmDao().getById(id)
        loaded = true
    }
    BackHandler(enabled = true) { /* the alarm can't be backed out of */ }
    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterVertically)
    ) {
        Text(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()), style = MaterialTheme.typography.displayLarge)
        alarm?.label?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.titleLarge) }
        val a = alarm
        when {
            a != null -> MissionHost(a, onSolved)
            loaded -> Button(onClick = onSolved) { Text("Dismiss") }
            else -> CircularProgressIndicator()
        }
    }
}
