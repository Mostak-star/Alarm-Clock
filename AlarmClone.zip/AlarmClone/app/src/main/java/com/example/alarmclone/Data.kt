package com.example.alarmclone

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

const val EXTRA_ID = "alarm_id"

enum class Mission(val title: String, val hint: String) {
    NONE("None", "Just a dismiss button"),
    MATH("Math", "Solve 3 math problems"),
    TYPING("Typing", "Type a phrase exactly"),
    SHAKE("Shake", "Shake the phone 30 times"),
    QR("QR code", "Scan a QR code (you can register your own)"),
    PHOTO("Photo", "Take a photo of a chosen object")
}

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hour: Int,
    val minute: Int,
    val days: Int = 0,             // bitmask: Mon=1 ... Sun=64; 0 = ring once
    val label: String = "",
    val mission: String = Mission.MATH.name,
    val missionParam: String = "", // typing phrase, registered QR text, or photo target word
    val enabled: Boolean = true,
    val ringtone: String = "",     // empty = default alarm sound
    val volume: Int = 100,         // percent of the phone's max alarm volume
    val gradual: Boolean = false,  // fade the sound in over 30 seconds
    val boost: Boolean = false     // loudness enhancer (louder than max volume)
)

@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms ORDER BY hour, minute")
    fun observeAll(): Flow<List<AlarmEntity>>
    @Query("SELECT * FROM alarms")
    suspend fun getAll(): List<AlarmEntity>
    @Query("SELECT * FROM alarms WHERE id = :id")
    suspend fun getById(id: Int): AlarmEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(a: AlarmEntity): Long
    @Update suspend fun update(a: AlarmEntity)
    @Delete suspend fun delete(a: AlarmEntity)
}

@Database(entities = [AlarmEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao
    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "alarms.db")
                .fallbackToDestructiveMigration()
                .build().also { inst = it }
        }
    }
}
