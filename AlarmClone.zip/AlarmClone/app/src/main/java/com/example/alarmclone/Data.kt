package com.example.alarmclone

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

const val EXTRA_ID = "alarm_id"

enum class Mission(val title: String) {
    NONE("None"), MATH("Math"), TYPING("Typing"), SHAKE("Shake"), QR("QR code"), PHOTO("Photo")
}

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hour: Int,
    val minute: Int,
    val days: Int = 0,            // bitmask: Mon=1, Tue=2 ... Sun=64; 0 = ring once
    val label: String = "",
    val mission: String = Mission.MATH.name,
    val missionParam: String = "", // typing phrase, QR text, or photo target word
    val enabled: Boolean = true
)

@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms ORDER BY hour, minute")
    fun observeAll(): Flow<List<AlarmEntity>>
    @Query("SELECT * FROM alarms")
    suspend fun getAll(): List<AlarmEntity>
    @Query("SELECT * FROM alarms WHERE id = :id")
    suspend fun getById(id: Int): AlarmEntity?
    @Insert suspend fun insert(a: AlarmEntity): Long
    @Update suspend fun update(a: AlarmEntity)
    @Delete suspend fun delete(a: AlarmEntity)
}

@Database(entities = [AlarmEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao
    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "alarms.db")
                .build().also { inst = it }
        }
    }
}
