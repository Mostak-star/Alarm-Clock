package com.example.alarmclone

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.*
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private var enhancer: LoudnessEnhancer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var currentId = -1
    private var volumePct = 100
    private var gradual = false
    private var startedAt = 0L
    private var ringing = false
    private var destroyed = false

    private val tick = object : Runnable {
        override fun run() {
            if (destroyed) return
            applyVolume()
            if (!RingActivity.visible) launchRing()
            // Safety: stop on its own after 10 minutes
            if (System.currentTimeMillis() - startedAt > 10 * 60 * 1000L) { stopSelf(); return }
            handler.postDelayed(this, 2000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        currentId = intent?.getIntExtra(EXTRA_ID, -1) ?: -1
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
        val ring = PendingIntent.getActivity(
            this, currentId,
            Intent(this, RingActivity::class.java).putExtra(EXTRA_ID, currentId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Wake up!")
            .setContentText("Tap to complete your mission")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(ring, true)
            .setContentIntent(ring)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NID, n)

        val appCtx = applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.get(appCtx).alarmDao()
            val a = dao.getById(currentId)
            if (a != null) {
                if (a.days != 0) AlarmScheduler.schedule(appCtx, a)
                else dao.update(a.copy(enabled = false))
            }
            handler.post { if (!destroyed) startRinging(a) }
        }
        return START_NOT_STICKY
    }

    private fun applyVolume() {
        runCatching {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, (max * volumePct / 100).coerceAtLeast(1), 0)
        }
        val f = if (gradual)
            (0.15f + 0.85f * ((System.currentTimeMillis() - startedAt) / 30000f)).coerceAtMost(1f)
        else 1f
        player?.setVolume(f, f)
    }

    private fun launchRing() {
        runCatching {
            startActivity(
                Intent(this, RingActivity::class.java).putExtra(EXTRA_ID, currentId)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }
    }

    private fun buildPlayer(uri: Uri): MediaPlayer? = try {
        MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            setDataSource(this@AlarmService, uri)
            isLooping = true
            prepare()
        }
    } catch (e: Exception) { null }

    private fun startRinging(a: AlarmEntity?) {
        if (ringing) return
        ringing = true
        volumePct = a?.volume ?: 100
        gradual = a?.gradual ?: false
        startedAt = System.currentTimeMillis()

        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alarm:ring").apply { acquire(11 * 60 * 1000L) }

        launchRing()

        val default = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val custom = a?.ringtone?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
        val p = custom?.let { buildPlayer(it) } ?: buildPlayer(default)
        player = p
        if (p != null) {
            if (a?.boost == true) {
                runCatching {
                    enhancer = LoudnessEnhancer(p.audioSessionId).apply {
                        setTargetGain(1000) // +10 dB
                        setEnabled(true)
                    }
                }
            }
            applyVolume()
            p.start()
        }
        val vib = getSystemService(Vibrator::class.java)
        vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0))
        handler.postDelayed(tick, 2000)
    }

    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        runCatching { enhancer?.release() }
        player?.runCatching { stop(); release() }
        player = null
        runCatching { getSystemService(Vibrator::class.java).cancel() }
        wakeLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    companion object { const val CH = "alarm_channel"; const val NID = 42 }
}
